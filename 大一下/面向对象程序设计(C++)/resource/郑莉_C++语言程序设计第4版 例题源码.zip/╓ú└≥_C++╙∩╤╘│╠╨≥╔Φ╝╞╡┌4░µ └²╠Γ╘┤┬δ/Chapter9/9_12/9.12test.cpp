#include<iostream>
#include"9_12.h" 
using namespace std;

int main(){
	int a[5] = {3,2,5,6,1};
	int size=5;
	selectionSort(a, size);
	for(int i=0; i < size; i++){
		cout << a[i];
	}
	return 0;
}


