
public class Lamp implements myObserver{
    @Override
    public void update(Sensor sensor) {
        System.out.println("警示灯闪烁");
    }
}
