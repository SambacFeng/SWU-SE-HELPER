public class Main {
    public static void main(String[] args) {
        Sensor sensor = new Sensor();
        sensor.addObserver(new Lamp());
        sensor.addObserver(new Alarm());

        for(int i = 0;i < 10;i++){
            System.out.printf("第%d次温度变化\n",i+1);
            double temp=Math.random() * 100;
            sensor.change(temp);
        }
    }
}