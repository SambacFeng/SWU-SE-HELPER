
public interface myObserver {
    public void update(Sensor sensor);
}
