import java.util.ArrayList;
import java.util.List;


public class Sensor {
    List<myObserver> observers = new ArrayList<>();
    public List<myObserver> getObservers() {
        return observers;
    }
    public void addObserver(myObserver observer) {
        observers.add(observer);
    }
    public void notifyObserver(){
        for(myObserver observer:getObservers())
        {
            observer.update(this);
        }

    }
    public void change(double temp)
    {
        if(temp > 50)
            notifyObserver();
    }
}
