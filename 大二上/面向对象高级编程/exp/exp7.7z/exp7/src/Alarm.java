public class Alarm implements myObserver{

    @Override
    public void update(Sensor sensor) {
        System.out.println("警示器响了");
    }
}
