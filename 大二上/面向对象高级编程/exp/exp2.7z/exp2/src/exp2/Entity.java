package exp2;

import java.util.HashMap;
import java.util.Map;

import javafx.geometry.Point2D;
import javafx.scene.image.Image;
import javafx.scene.transform.Rotate;


public class Entity implements Cloneable
{

	private Point2D location;
	private double height,width;
	private Map<String,Image> skinBox = new HashMap<String,Image>();//����-1--8������1-8
	private int state = 1;
	private double speed = 10;
	
	@Override
	public Entity clone() 
	{
		Entity entity = null;
		try {
			entity = (Entity) super.clone();
			entity.setLocation(new Point2D(entity.getLocation().getX(),entity.getLocation().getY()));
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return entity;
	}
	
	public Entity(String imgsPath)
	{
		for(int i = 1;i <= 8; i++)
		{
			Image img = new Image("file:/"+ imgsPath + "/0" + i + ".jpg");
			System.out.println(img.getPixelReader());
			Image imgRev = ImageTool.rotate(img,180, Rotate.Y_AXIS);
			skinBox.put(String.valueOf(i), img);
			skinBox.put(String.valueOf(-i), imgRev);
		}
		setLocation(new Point2D(10,10));
		setHeight(getLook().getHeight());
		setWidth(getLook().getWidth());
	}
	
	public void moveLeft()
	{
		location = location.add(-speed, 0);
		if(state < 0)
		{
			state = (state - 1) % 8 - 1;	
		}
		else
		{
			state = -1;
		}
	}
	public void moveRight()
	{
		location = location.add(speed,0);
		if(state > 0)
		{
			state = (state + 1) % 8 + 1;
		}else
		{
			state = 1;
		}
	}
	
	public void setSkin(Map<String,Image>skin)
	{
		skinBox = skin;
	}
	public void setState(Integer state)
	{
		this.state =state;
	}
	public Image getLook()
	{
		return skinBox.get(String.valueOf(state));
	}
	public Point2D getLocation()
	{
		return location;
	}
	public void setLocation(Point2D location)
	{
		this.location = location;
	}
	public double getHeight()
	{
		return height;
	}
	public void setHeight(double height)
	{
		this.height = height;
	}
	public double getWidth()
	{
		return width;
	}
	public void setWidth(double width)
	{
		this.width = width;
	}
	public double getSpeed()
	{
		return speed;
	}
	public void setSpeed(double speed)
	{
		this.speed = speed;
	}
	public int getState()
	{
		return this.state;
	}
	
}
