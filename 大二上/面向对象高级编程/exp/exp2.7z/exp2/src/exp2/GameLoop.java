package exp2;

import javafx.animation.AnimationTimer;

public abstract class GameLoop extends AnimationTimer {
	private long startTime;//循环开始时间
	private long nextTick;//下一次逻辑刷新时间
	private final int TICKS_PER_SECOND = 10;//刷新时间间隔
	private final int SKIP_TICKS = 1000 / TICKS_PER_SECOND;
	private final int MAX_FRAMESKIP = 10;
	
	public GameLoop()
	{
		super();
		startTime = System.currentTimeMillis();
		nextTick = 0L;
		
	}
	@Override
	public void handle(long now)
	{
		preprocess();
		int loops = 0;
		while((System.currentTimeMillis() - startTime) > nextTick && loops < MAX_FRAMESKIP)
		{
			refresh();
			nextTick += SKIP_TICKS;
			loops++;
		}
		display();
	}
	public abstract void preprocess();//交互相关的预处理，对用户输入的处理进行提纯分析
	public abstract void refresh();//刷新业务状态，对输入的信息进行逻辑刷新
	public abstract void display();//界面刷新，把的到逻辑结果进行刷新
}

