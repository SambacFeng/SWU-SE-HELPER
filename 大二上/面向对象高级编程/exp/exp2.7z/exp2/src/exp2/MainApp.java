package exp2;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.lang.Math;

public class MainApp extends Application 
{
	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		
		Entity e1 = new Entity("D:\\role/r1");
		Entity e2 = new Entity("D:\\role/r2");
		e2.setLocation(new Point2D(0, 200));
		
		
		List<Entity> list = new ArrayList<Entity>();
		for(int i = 0; i < 3; i++) {

			Entity r1 = e1.clone(); r1.setSpeed(i * 3 + Math.random());

			Entity r2 = e2.clone(); r2.setSpeed(i * 3 + Math.random());
			list.add(r1);
			list.add(r2);
			}
		GameView.getGameView().addAll(list);
		GameLoop gameLoop = new GameLoop() 
		{
		@Override
		public void preprocess() {}
		@Override
		public void refresh() 
		{
			for(Entity entity : list) 
			{
				Point2D location = entity.getLocation();
				if(entity.getState() > 0) 
				{
					entity.moveRight();
					if(location.getX() + entity.getWidth() >= GameView.getGameView().getWidth()) 
					{
						entity.moveLeft();
					}
				}
				else 
				{
					entity.moveLeft();
					if(location.getX() <= 0) 
					{
						entity.moveRight();
					}
				}
			}
		}
			@Override
			public void display() 
			{
				GameView.getGameView().render();
			}
		};
		gameLoop.start();
		
		GameView.getGameView().setWidth(1000);
		GameView.getGameView().setHeight(600);
		Pane backPane = new Pane(GameView.getGameView());
		
		Scene scene = new Scene(backPane);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Game");
		primaryStage.show();
	}
	public static void main(String[] args) 
	{
		launch();
	}
}
