package exp2;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;


public class GameView extends Canvas
{
	
	private static GameView instance_gameview = new GameView();//����ģʽ���е���ģʽ�Ĵ�����Ψһ����instance_gameview
	private List<Entity> entities = new ArrayList<Entity>();//����ʵ��list�������洢��Ҫ��Ⱦ��ʵ��
	
	private GameView(){}
	public static GameView getGameView()
	{
		return instance_gameview;
	}
	
	public void render()
	{
		this.getGraphicsContext2D().clearRect(0, 0, this.getWidth(), this.getHeight());
		for(Entity e : entities)
		{
			draw(e);
		}
	}
	private void draw(Entity entity)
	{
		GraphicsContext gc = this.getGraphicsContext2D();
		Point2D location = entity.getLocation();
		double w = entity.getWidth();
		double h = entity.getHeight();
		gc.drawImage(entity.getLook(),location.getX(),location.getY(),w,h);
	}
	
	public void addAll(List<Entity> entities)
	{
		this.entities.addAll(entities);
	}
	
	public void add(Entity entity)
	{
		entities.add(entity);
	}
	public void remove(Entity entity)
	{
		
	}
}
