/*
package exp2;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Entity;

import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MainApp extends Application;
{
	@override
	public void start (Stage primaryStage) throws Exception
	{
		Entity e1 = new Entity("D:\\Java\\exp2\\role/r1");
		Entity e2 = new Entity("D:\\Java\\exp2\\role/r2");
		e2.setLocation(new Point2D(0,200));
		
		List<Entity> list = new ArrayList<Entity>();
		for(int i = 0; i < 3； i++)
		{
			Entity r1 = e1.cloneNode();r1.setSpeed(i*3+Math.random());
			Entity r2 = e2.cloneNode();r2.setSpeed(i*3+Math.random());
			list.add(r1);
			list.add(r2);
		}
		GameView.getView().addAll(list);
		
		GameLoop gameloop = new GameLoop()
		{
			@Override
			public void preprocess() {}
			@Override
			public void refresh()
			{
				for(Entity entity : list)
				{
					Point2D location = entity.getLocation();
					if(entity.getState()>0)
					{
						entity.moveRight();
						if(location.getX()+entity.getWidth()>=GameView.getView().getWidth())
						{
							entity.moveLeft();
						}
						else
						{
							enetity.moveLeft();
							if(location.getX()<=0)
							{
								entity.moveRight();
							}
						}
					}
				}
			}
				@Override
				public void display()
				{
					GameView.getView().render();
				}
		};
	}
}


public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
*/
