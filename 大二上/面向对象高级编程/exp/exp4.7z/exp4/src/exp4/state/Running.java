package exp4.state;

import exp4.entity.Role;

public class Running implements State {

	@Override
	public void handle(ControlType type, Role role) {
		switch(type) {
		case LEFT: left(role); running(role); break;
		case RIGHT: right(role); running(role); break;
		case JUMP: jump(role);break;
		case RELEASE:stand(role);break;
		default: running(role); break;
	}
}

public void left(Role role) {
	role.setSpeedX(Role.SPEED_MAX);
	role.setDirectionX(-1);
	role.setIndex(-2);
}

public void right(Role role) {
	role.setSpeedX(Role.SPEED_MAX);
	role.setDirectionX(1);
	role.setIndex(2);
}

public void running(Role role) {
	role.setSpeedX(Role.SPEED_MAX);
}
public void jump(Role role){
	role.setState(new Jumping());
	
}
public void stand(Role role){
	role.setSpeedX(0);
	role.setState(new Standing());
	role.setIndex(1*role.getDirectionX());
}
}