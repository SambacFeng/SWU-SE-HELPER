package exp4.state;

public enum ControlType {
	LEFT,RIGHT,JUMP,RELEASE,NOTHING
}
