package exp4.state;

import exp4.entity.Role;

public interface State {
	public abstract void handle(ControlType type, Role e);
}
