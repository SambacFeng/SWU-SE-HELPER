package exp4.state;

import exp4.entity.Role;

public class Standing implements State {

	@Override
	public void handle(ControlType type, Role role) {
		// TODO Auto-generated method stub
		switch(type) {
		case LEFT: left(role); break;
		case RIGHT: right(role); break;
		case JUMP: jump(role);break;
		default:
			break;
		}
	}
	public void left(Role role) {
		role.setState(new Running());
		role.setDirectionX(-1);
		role.setIndex(-1);
	}
	
	public void right(Role role) {
		role.setState(new Running());
		role.setDirectionX(1);
		role.setIndex(1);
	}	
	public void jump(Role role){
		if(role.getDirectionX()==1) role.setIndex(3);
		else role.setIndex(-3);
		role.setSpeedY(10);
		role.setSpeedX(10);
		role.setDirectionY(-1);
		role.setState(new Jumping());
	}
		
		
		
	}
		