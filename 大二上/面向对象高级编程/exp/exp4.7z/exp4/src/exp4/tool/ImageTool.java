package exp4.tool;

import java.io.IOException;

import javafx.geometry.Point3D;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class ImageTool {
	public static void main(String[] args) throws IOException {
		ImageTool i = new ImageTool();
		i.displayPath();
	}
	
	public void displayPath() {
		System.out.println(this.getClass().getResource("").getPath());
	}
	
	// �ü�ͼƬ
	public static Image clipImage(Image source, int x, int y, int w, int h) {
		PixelReader pr = source.getPixelReader();
		WritableImage wi = new WritableImage(pr, x, y, w, h);
		return wi;
	}
	
	// ����ͼƬ
	public static Image scale(Image source, int targetWidth, int targetHeight, boolean preserveRatio) {
	    ImageView imageView = new ImageView(source);
	    imageView.setPreserveRatio(preserveRatio);
	    imageView.setFitWidth(targetWidth);
	    imageView.setFitHeight(targetHeight);
	    SnapshotParameters parameters = new SnapshotParameters();
	    parameters.setFill(Color.TRANSPARENT);
	    return imageView.snapshot(parameters, null);
	}
	
	// ��תͼƬ
	public static Image rotate(Image source, double angle, Point3D axis) {
		ImageView imageView = new ImageView(source);
	    imageView.setFitWidth(source.getWidth());
	    imageView.setFitHeight(source.getHeight());
	    imageView.setRotate(angle);
	    imageView.setRotationAxis(axis);
		SnapshotParameters parameters = new SnapshotParameters();
		parameters.setFill(Color.TRANSPARENT);
		return imageView.snapshot(parameters, null); 
	}
}
