import java.io.PrintWriter;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalcUnitProxy extends CalcUnit {

    CalcUnit cu;
    PrintWriter pw;
    @Override
    public boolean fit(String operator) {
        Date date = GregorianCalendar.getInstance().getTime();
        pw.print(date);
        pw.print("当前操作符");
        pw.print(cu.toString());
        pw.print("是否符合当前计算单元：");
        pw.println(cu.fit(operator));
        return cu.fit(operator);
    }
    @Override
    public double calc(double x, double y) {
        Date date = GregorianCalendar.getInstance().getTime();
        pw.print(date);
        pw.print("计算");
        pw.print(x);
        pw.print(cu.toString());
        pw.print(y);
        pw.print("的结果为:");
        pw.println(cu.calc(x,y));
        return cu.calc(x, y);
    }
    public void setCalcUnit(CalcUnit cu) {
        this.cu = cu;
    }
    public void setLogWrite(PrintWriter pw) {
        this.pw=pw;
    }
}
