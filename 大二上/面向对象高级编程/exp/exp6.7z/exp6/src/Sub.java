public class Sub extends CalcUnit{

    @Override
    public boolean fit(String operator) {
        if(operator.equals("-"))
            return true;
        else
            return false;
    }

    @Override
    public double calc(double x, double y) {
        return x-y;
    }
    @Override
    public String toString(){
        return "-";
    }
}