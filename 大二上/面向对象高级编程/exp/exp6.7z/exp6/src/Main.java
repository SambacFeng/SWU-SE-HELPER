import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CalcUnit[] list = {new Add(), new Sub(), new Mul(), new Div()};
        CalcUnitProxy proxy = new CalcUnitProxy();
        PrintWriter pw =null;
        File file = new File("D:\\Java\\实验6（需要实验报告）\\exp6\\log.txt");
        try{
            pw = new PrintWriter(file);
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        proxy.setLogWrite(pw);

        Scanner input = new Scanner(System.in);

        while(true){
            System.out.print("输入:");
            String line = input.nextLine();
            if(line.equals("exit"))
                break;
            String[] s = line.split(" ");
            if(s.length!=3)
                continue;
            double x = Double.parseDouble(s[0]);
            double y = Double.parseDouble(s[2]);
            String operator = s[1];

            for(CalcUnit cu:list){
                proxy.setCalcUnit(cu);
                if(proxy.fit(operator)){
                    System.out.printf("结果%4.2f\n",proxy.calc(x,y));
                    break;
                }
            }
            pw.flush();
        }
        pw.close();
        input.close();
    }
}