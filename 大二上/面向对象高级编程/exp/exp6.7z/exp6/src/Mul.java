public class Mul extends CalcUnit{

    @Override
    public boolean fit(String operator) {
        if(operator.equals("*"))
            return true;
        else
            return false;
    }

    @Override
    public double calc(double x, double y) {
        double z = x * y;
        return  z;
    }
    @Override
    public String toString(){
        return "*";
    }
}