public abstract class  CalcUnit implements Calculable{
    public abstract boolean fit(String operator);
}
