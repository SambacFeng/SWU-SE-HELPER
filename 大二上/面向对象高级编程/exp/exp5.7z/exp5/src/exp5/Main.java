package exp5;

import java.util.Scanner;
public class Main {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		// 创建链式结构的计算器 CalcUnit calculator = ?
		CalcUnit calculator=new Add(new Sub(new Mul(new Div(null))));
		while(true) {
			System.out.print("输入：");
			String commond = input.nextLine().trim();
			if(commond.equals("exit")) {
				break;
			}
			try {
				System.out.println("计算结果：" + calculator.handle(commond));
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		input.close();
	}
}
