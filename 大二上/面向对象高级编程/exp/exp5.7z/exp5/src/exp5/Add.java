package exp5;

public class Add extends CalcUnit {
	
	public Add(CalcUnit next) {
		super(next);
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean fit(String operator) {
		return operator.equals("+");
	}

	@Override
	public double calc(double x, double y) {
		// TODO Auto-generated method stub
		return x+y;
	}
	
}
