package exp5;

public class Mul extends CalcUnit {

	public Mul(CalcUnit next) {
		super(next);
		// TODO Auto-generated constructor stub
	}


	@Override
	public boolean fit(String operator) {
		if(operator.equals("*"))return true;
		else return false;
	}

	@Override
	public double calc(double x, double y) {
		// TODO Auto-generated method stub
		return x*y;
	}

}
