package exp5;
public class Div extends CalcUnit{
	public Div(CalcUnit next) {
		super(next);
	}
	public double calc(double x,double y)
	{
		
		return x/y;
	}
	public boolean fit(String operator){
        return operator.equals("/");
    }
}

