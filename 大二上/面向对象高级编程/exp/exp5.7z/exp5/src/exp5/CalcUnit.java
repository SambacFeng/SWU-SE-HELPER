package exp5;

public abstract class CalcUnit {
	private CalcUnit next = null;
	public abstract boolean fit(String operator);
	public abstract double calc(double x, double y);
	public CalcUnit(CalcUnit next)
	{
		this.next = next;
	}
	public double handle(String opera) throws Exception 
	{
		String s[]=opera.trim().split(" ");
		double x=Double.parseDouble(s[0]);
		double y=Double.parseDouble(s[2]);
		String operator=s[1];
		if(fit(operator))
		{
			return calc(x,y);
		}
		else if(next != null)
		{
			//System.out.println("xx");
			return next.handle(opera);
			//System.out.println(sum);
		}
		else 
		{
			throw new Exception("没找到合适的处理");
		}
	}
}
