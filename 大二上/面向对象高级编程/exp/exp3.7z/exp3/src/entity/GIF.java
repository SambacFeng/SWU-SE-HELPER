package entity;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.image.Image;

public class GIF {
	List<Frame> frames = new ArrayList<Frame>();
	
	public void add(Frame frame)
	{
		frames.add(frame);
	}
	
	public Image getImage(int index){
		return getFrame(index).getImage();
	}
	
	public Frame getFrame(int index){
		return frames.get(index);
	}
	
	public int count()
	{
		return frames.size();
	}
	
	
	

}
