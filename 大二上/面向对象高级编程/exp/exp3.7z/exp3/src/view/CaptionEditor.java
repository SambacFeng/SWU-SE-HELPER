package view;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CaptionEditor extends ScrollPane{
	private GIFViewer viewer;
	private VBox editorBox;
	private Button addBtn;
	private Button applyBtn;
	private List<EditorItem> list = new ArrayList<EditorItem>();
	
	public CaptionEditor(GIFViewer viewer) {
		this.viewer = viewer;
		editorBox = new VBox();
		addBtn = new Button("����");
		addBtn.setFont(new Font(16));
		addBtn.setPrefWidth(130);
		applyBtn = new Button("Ӧ��");
		applyBtn.setFont(new Font(16));
		applyBtn.setPrefWidth(130);
		VBox.setMargin(addBtn, new Insets(10, 10, 10, 10));
		VBox.setMargin(applyBtn, new Insets(10, 10, 10, 10));
		this.setContent(editorBox);
		
		update();
		
		// ������Ļ�༭ģ��
		addBtn.setOnAction(e -> {
			add();
		});
		
		applyBtn.setOnAction(e -> {
			update();
		});
	}
	
	// ��Ļ��Ϣ�仯�����
	public void update() {
		String[] captions = new String[viewer.count()];
		for(EditorItem item : list) {
			for(int i = item.getStart(); i < item.getEnd(); i++) {
				captions[i] = item.getContent();
			}
		}
		viewer.setCaptions(captions);
		editorBox.getChildren().clear();
		editorBox.getChildren().addAll(list);
		editorBox.getChildren().addAll(addBtn, applyBtn);
	}
	
	public void add() {
		add(new EditorItem());
	}
	
	public void add(EditorItem item) {
		list.add(item);
		update();
	}
	
	public void remove(EditorItem item) {
		list.remove(item);
		update();
	}
	
	private class EditorItem extends VBox{
		private TextField content;
		private TextField start;
		private TextField end;
		
		public EditorItem() {
			this.setPadding(new Insets(5, 5, 5, 5));
			start = new TextField();
			start.setText("0");
			start.setPrefWidth(50);
			end = new TextField();
			end.setPrefWidth(50);
			end.setText("0");
			content = new TextField();
			content.setPrefWidth(130);
			VBox.setMargin(content, new Insets(5, 0, 5, 0));
			Button btn = new Button("ɾ������Ļ");
			btn.setPrefWidth(130);
			HBox hbox = new HBox();
			Label l1 = new Label("��");
			Label l2 = new Label("��");
			l1.setFont(new Font(16));
			l2.setFont(new Font(16));
			hbox.getChildren().addAll(l1, start, l2, end);
			
			this.getChildren().addAll(hbox, content, btn);

			btn.setOnAction(e -> {
				CaptionEditor.this.remove(this);
			});
		}
		
		public int getStart() {
			return Integer.parseInt(this.start.getText());
		}
		
		public int getEnd() {
			return Integer.parseInt(this.end.getText());
		}
		
		public String getContent() {
			return this.content.getText();
		}
	}
	
}
