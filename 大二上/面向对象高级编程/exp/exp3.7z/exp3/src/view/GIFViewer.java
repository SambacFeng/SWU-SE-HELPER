package view;

import adapter.GIFReader;
import adapter.GIFWriter;
import adapter.IGIFReader;
import adapter.IGIFWriter;
import entity.Frame;
import entity.GIF;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class GIFViewer extends VBox{
	private Canvas view = new Canvas(); // ����
	private Slider slider = new Slider(); // ������
	private GIF gif; // ��ͼ
	private String[] captions; // ��Ļ
	private int index; // ��ǰ֡����
	
	private IGIFReader reader;
	private IGIFWriter writer;
	
	public GIFViewer() {
		this(new GIFReader(), new GIFWriter());
	}
	
	public GIFViewer(IGIFReader reader, IGIFWriter writer) {
		setReader(reader);
		setWriter(writer);
		
		slider.setShowTickMarks(true);
		slider.setShowTickLabels(true);
		slider.setBlockIncrement(1);
		slider.setMajorTickUnit(1);
		setMargin(view, new Insets(10, 10, 10, 10));
		
		view.setWidth(800);
		view.setHeight(500);
		this.getChildren().addAll(view, slider);

		// ���ӻ����¼��������鿴ÿ֡ͼƬ
		slider.valueProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> arg0, Number oldValue, Number newValue) {
				if(gif != null) {
					changeTo(newValue.intValue());
					render();
				}	
			}
		});
	}
	
	public int count() {
		if(gif != null) {
			return gif.count();
		}
		return 0;
	}
	
	public void setCaptions(String[] captions) {
		this.captions = captions;
	}
	
	public void setReader(IGIFReader reader) {
		this.reader = reader;
	}
	
	public void setWriter(IGIFWriter writer) {
		this.writer = writer;
	}
	
	public boolean hasGIF() {
		if(gif != null)
			return true;
		return false;
	}
	
	// �ļ���ʽ���
	public void export(String path) {
		if(gif != null) {
			writer.write(gifWithCaptions(), path);
		}
	}
	
	// �ļ���ʽ����
	public void load(String path) {
		load(reader.read(path));
	}
	
	// ���ض�ͼ
	public void load(GIF gif) {
		this.gif = gif;
		captions = new String[gif.count()];
		slider.setMax(count() - 1);
		changeTo(0);
	}
	
	// �޸�״̬
	public void changeTo(int index) {
		this.index = index;
		slider.setValue(index);
		render();
	}

	// ���ɴ���Ļ�Ķ�ͼ
	public GIF gifWithCaptions() {
		if(gif != null) {
			GIF newgif = new GIF();
			for(int i = 0; i < gif.count(); i++) {
				Frame frame = new Frame(render(i), gif.getFrame(i).getDelay());
				newgif.add(frame);
			}
			return newgif;
		}
		return null;
	}
	
	// ��Ⱦһ֡
	public void render() {
		render(index);
	}
	
	// ��Ⱦָ��֡
	public Image render(int index) {
		
		GraphicsContext gc = view.getGraphicsContext2D();
		// ����
		gc.clearRect(0, 0, this.getWidth(), this.getHeight());
		// ��Ⱦ
		if(gif != null) {
			gc.drawImage(gif.getImage(index), 0, 0, view.getWidth(), view.getHeight());
			String text = captions[index];
			//System.out.println(text);
			if(text != null) {
				gc.save();
				gc.setFill(Color.BLUE);
				gc.setStroke(Color.WHITE);
				gc.setFont(new Font(32));
				gc.setLineWidth(2.0);
				//gc.strokeText(text, 0, 0);
				gc.strokeText(text, view.getWidth() / 2 - 32 * text.length() / 2, view.getHeight() - 32);
				gc.fillText(text, view.getWidth() / 2 - 32 * text.length() / 2, view.getHeight() - 32);
				gc.restore();
			}
			SnapshotParameters sp =  new SnapshotParameters();
			return view.snapshot(sp, null);
		}
		return null;
	}
	
}
