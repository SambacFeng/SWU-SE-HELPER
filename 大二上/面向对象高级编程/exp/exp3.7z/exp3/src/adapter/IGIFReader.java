package adapter;

import entity.GIF;

public interface IGIFReader {
	public GIF read(String path);
}
