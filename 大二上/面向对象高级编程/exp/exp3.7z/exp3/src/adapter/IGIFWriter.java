package adapter;

import entity.GIF;

public interface IGIFWriter {
	public void write(GIF gif, String path);
	
}