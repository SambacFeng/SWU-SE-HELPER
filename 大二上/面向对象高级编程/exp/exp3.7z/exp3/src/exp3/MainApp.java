package exp3;

import java.io.File;

import view.CaptionEditor;
import view.GIFViewer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainApp extends Application {
	int time = 100;
	boolean playing = false;

	@Override
	public void start(Stage primaryStage) throws Exception {
		// ���岼��
		SplitPane layout = new SplitPane();
		layout.setDividerPositions(0.75f, 0.25f);
		
		// չʾ�����ı��������򲼾�
		VBox viewLayout = new VBox();
		
		// �ļ�ѡ������
		HBox fileLayout = new HBox();
		fileLayout.setPadding(new Insets(10));
		Label label = new Label("�ļ���");
		label.setFont(new Font(16));
		TextField filePath = new TextField();
		filePath.setEditable(false);
		filePath.setPrefWidth(530);
		Button browse = new Button("���..");
		Button playBtn  = new Button("����");
		Button saveBtn = new Button("����");
		fileLayout.getChildren().addAll(label, filePath, browse, playBtn, saveBtn);
		HBox.setMargin(filePath, new Insets(0, 10, 0, 10));
		HBox.setMargin(browse, new Insets(0, 0, 0, 10));
		HBox.setMargin(playBtn, new Insets(0, 0, 0, 10));
		HBox.setMargin(saveBtn, new Insets(0, 0, 0, 10));
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("ѡ��̬ͼƬ");
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("��ͼ", "*.gif"));
		
		// �鿴������
		GIFViewer viewer = new GIFViewer();

		// ��Ļ�༭����
		CaptionEditor editor = new CaptionEditor(viewer);
		
		// �������
		viewLayout.getChildren().addAll(fileLayout, viewer);
		layout.getItems().addAll(viewLayout, editor);
		
		// ������ťѡ���ļ�·��
		browse.setOnAction(e -> {
			File selectedFile = fileChooser.showOpenDialog(primaryStage);
			if (selectedFile != null) {
				filePath.setText(selectedFile.getAbsolutePath());
				viewer.load(selectedFile.getAbsolutePath());
			}
		});

		
		// ���Ŷ�̬ͼƬ
		playBtn.setOnAction(e -> {
			if(viewer.hasGIF() && playing == false) {
				Timeline tl = new Timeline();
				tl.setCycleCount(viewer.count());
				tl.getKeyFrames().add(new KeyFrame(Duration.millis(time), new EventHandler<ActionEvent>() {
					int i = 0;
					@Override
					public void handle(ActionEvent arg0) {
						viewer.changeTo(i++);
					}
				}));
				tl.play();
				playing = true;
				tl.setOnFinished(fe -> {
					viewer.changeTo(0);
					playing = false;
				});
			}
		});
		
		// ������̬ͼƬ
		saveBtn.setOnAction(e -> {
			String fileName = filePath.getText().replaceAll(".gif", "_new.gif");
			viewer.export(fileName);
		});
		
		layout.setPrefWidth(1000);
		layout.setPrefHeight(600);
		
		Scene scene = new Scene(layout);
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.setTitle("���Ӷ�ͼ��Ļ");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
