#include "pch.h"
#include "company.h"

int main()
{
	Company cmp;

	cmp.inputEmployee();
	cmp.findBestPaid();
	cmp.printBestPaid();

	return 0;
}